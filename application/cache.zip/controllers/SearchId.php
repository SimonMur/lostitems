<?php
 if ( ! defined('BASEPATH')) exit('No direct Scripts allowed');
 class SearchId extends CI_Controller{
  public function _construct()
  {
   parent::_construct();
   //load form helper
   $this->load->helper('form');
   $this->load->helper('url');
// load 'session' 
 $this->load->library('session');
    // load 'validation' class
    $this->load->library('form_validation');
    $this->load->database();
   $this->load->model('SearchId_model');
  }
  public function index(){
   $this->load->view('header');
   $this->load->view('searchview');
    $this->load->view('footer');
  }
  public function search(){
    $IdNo   =   $this->input->post('IdNo');
	 $this->load->model('searchId_model');
     $data['results']= $this->searchId_model->search($IdNo);
	  $this->load->view('header');
      $this->load->view('searchresult',$data);
      $this->load->view('footer');
  }
 }
 ?>