<?php
 if ( ! defined('BASEPATH')) exit('No direct Scripts allowed');
  class Usercontacts extends CI_Controller
  {
    public function __construct()
{
    parent::__construct();
   // load 'url' helper
    $this->load->helper('url');

    // load 'form' helper
    $this->load->helper('form');

// load 'session' 
 $this->load->library('session');
    // load 'validation' class
    $this->load->library('form_validation');
    $this->load->database();
}
function index()
{
        $this->load->view('header');
		$this->load->view('footer');
   //set validation rules
    $this->form_validation->set_rules('name', 'Name', 'trim|required|xss_clean|min_length[2]|max_length[30]');
	$this->form_validation->set_rules('PNo', 'Phone Number', 'trim|required|integer|min_length[10]|max_length[10]');
	$this->form_validation->set_rules('email', 'Email already exists .Please fill in the your email adrress .', 'required|valid_email|is_unique[usersfoundid_contacts.email]');

//checking validation and inserting data
if($this->form_validation->run() == false){
  //fail validation
  $this->load->view('contacterror');
}
else{
  //Pass Validation
  $data =array(
  'Name'=>$this->input->post('name'),
  'Email'=>$this->input->post('Email'),
  'Phone_Number'=>$this->input->post('PNo'),
  );
  //Insert the data to the database
  $this->db->insert('usersfoundid_contacts',$data);
  //Display success data
 $this->session->set_flashdata('msg', '<div class="alert alert-success text-center">Success in adding Lost ID Document details!!!</div>');
        redirect('SearchId/index');
} 
}
//custom validation function to accept only alpha and space input
function alpha_only_space($str)
{
    if (!preg_match("/^([-a-z ])+$/i", $str))
    {
        $this->form_validation->set_message('alpha_only_space', 'The %s field must contain only alphabets or spaces');
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}
}
 ?>