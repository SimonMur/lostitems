  <script src="<?php echo base_url('assets/js/jquery.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/jquery-ui.js') ?>"></script>
  <script src="<?php echo base_url('assets/js/bootstrap.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/skdslider.min.js') ?>"></script>
	<script src="<?php echo base_url('assets/js/wow.min.js') ?>"></script>
</body>
</html>