<body>
  <nav class="navbar navbar-default" role="navigation"> 
        <div class="navbar-header"> 
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse">
                 <span class="sr-only">Toggle navigation</span> 
                <span class="icon-bar"></span> 
                <span class="icon-bar"></span>
                 <span class="icon-bar"></span> 
            </button>
            <a class="navbar-brand" href="#">Lost ID</a> 
        </div> 
     <div class="collapse navbar-collapse" id="example-navbar-collapse">
            <ul class="nav navbar-nav">
            <li><a href="<?php echo site_url('welcome/index'); ?>">Home</a></li>
			<li ><a href="<?php echo site_url('reportlost/index'); ?>">Report My Lost ID</a></li>
			<li ><a href="<?php echo site_url('about/index'); ?>">About</a></li>
			<li class="active"><a href="<?php echo site_url('tips/index'); ?>">Tips</a></li>
			 <li><a href="<?php echo site_url('contact/index'); ?>">Contact</a></li>
			 <li><a href="<?php echo site_url('otherlost/index'); ?>">Report Other Items</a></li>
                </ul> 
        </div> 
    </nav>
	<div class="home"style="margin-top:0px;padding-top:0px;">
	<br>
    <div class="row"style="margin-top:0px;padding-top:0px;">
    <div class="col-md-12">
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
		<br>
	<br>
	<br>
	<br>
	<br>
	<br>
		<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	
	<p class="text-center"style="color:white;">Awaiting Live Feed</p>
		<br>
	<br>
	<br>
	<br>
	<br>
	<br>	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
    </div><!--col-md-12-->
    </div>
    <!---row-->
</div><!---Home-->
</body>