<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" context="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <title>Lost ID</title>
    <meta name="description" content="">
    <link href="<?php echo base_url('assets/css/bootstrap.css') ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/style.css') ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/skdslider.css') ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/animate.css') ?>" rel="stylesheet"> 
	<link href="<?php echo base_url('assets/css/ionicons.css') ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/jquery-ui.theme.css') ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/jquery-ui.css') ?>" rel="stylesheet">
	<link href="<?php echo base_url('http://fonts.googleapis.com/css?family=Roboto:400,300,100') ?>" rel="stylesheet">
	<link href="<?php echo base_url('http://code.jquery.com/ui/1.11.0/jquery-ui.js')?>">
    <link href="<?php echo base_url('assets/css/font-awesome.min.css') ?>" rel="stylesheet">
    <script src="<?php echo base_url('assets/js/bootstrap.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/jquery.min.js') ?>"></script>

	<script>
   $(function() {
    $( "#datepicker" ).datepicker();
    $( "#format" ).change(function() {
      $( "#datepicker" ).datepicker( "option", "dateFormat", $( this ).val() );
    });
  });
	</script>
</head>
<body>
</body>
</html>