<head>
</head>
<body>
  <nav class="navbar navbar-default" role="navigation"> 
        <div class="navbar-header"> 
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse">
                 <span class="sr-only">Toggle navigation</span> 
                <span class="icon-bar"></span> 
                <span class="icon-bar"></span>
                 <span class="icon-bar"></span> 
            </button>
            <a class="navbar-brand" href="#">Lost ID</a> 
        </div> 
     <div class="collapse navbar-collapse" id="example-navbar-collapse">
            <ul class="nav navbar-nav">
              <li><a href="<?php echo site_url('welcome/index'); ?>">Home</a></li>
			  <li  ><a href="<?php echo site_url('reportlost/index'); ?>">Report Lost ID</a></li>
			     <li class="active"><a href="<?php echo site_url('SearchId/index'); ?>">Search My Lost ID</a></li>
			  <li><a href="<?php echo site_url('about/index'); ?>">About</a></li>
			  <li><a href="<?php echo site_url('tips/index'); ?>">Tips</a></li>
			  <li><a href="<?php echo site_url('contact/index'); ?>">Contact</a></li>
        <li><a href="<?php echo site_url('otherlost/index'); ?>">Report Other Items</a></li>
                </ul> 
        </div> 
    </nav>
		<div class="home"style="margin-top:0px;padding-top:0px;">
	<br>
    <div class="row">
    <div class="col-md-12">
		<div class="col-md-2"></div>
     <div class="col-md-8">
	  <div class="panel panel-primary"> 
            <div class="panel-heading"style="background-color:#009933;"> 
                <h3 class="panel-title text-center">User Contacts</h3> 
            </div> 
            <div class="panel-body"style="background-color:black;margin-bottom:0px;"> 
			   <?php
			 $attributes=array("class" => "form-horizontal", "id" => "detailsform", "name" => "detailsform");
			 echo form_open("usercontacts/index", $attributes);?>
			 <fieldset>
		     <div class="form-group"> 
              <label for="firstname" class="col-sm-3 control-label"> Name</label> 
              <div class="col-sm-9">
                <input type="text" class="form-control" value="<?php echo set_value('name');?>" 
				id="name"  name="name" placeholder="Enter Your  Name"/> 
				      <span class="text-danger"><?php echo form_error('name'); ?></span>
              </div> 
          </div>
		     <div class="form-group"> 
              <label for="firstname" class="col-sm-3 control-label">Email</label> 
              <div class="col-sm-9">
                <input type="text" class="form-control" value="<?php echo set_value('email');?>" 
				id="email"  name="email" placeholder="Enter Your Email"/> 
				      <span class="text-danger"><?php echo form_error('email'); ?></span>
              </div> 
          </div>
		            <div class="form-group">
               <label for="IdNumber" class="col-sm-3 control-label">Phone Number</label> 
              <div class="col-sm-9"> 
                   <input type="text" class="form-control" value="<?php echo set_value('PNo');?>" 
				id="PNo"  name="PNo" placeholder="Enter your Phone Number"/> 
				      <span class="text-danger"><?php echo form_error('PNo'); ?></span>
                   </div>
               </div>
			   <div class="form-group">
                <input id="btn_add" name="btn_add" type="submit" class="btn btn-primary btn-md btn-block" value="Submit" style="background-color:#FF0000;margin-bottom:0px;"/>
            </div>
         </fieldset>
		 			
<p class="text-center"style="color:white">These details are considered confidential and will be shared with no one</p>
        <?php echo form_close(); ?>
<br>
			</div><!---Panel-body-->
			</div><!---Panel primary--->
	 </div><!---Col-md-8--->
	 <div class="col-md-2"></div>
    </div>
    </div>
    <!---row-->
	<br>
	<br>
	<br>
</div>
<!---Home-->	  
</body>  <!-- START FOOTER SECTION -->
  <footer id="footer">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <div class="footer_area">
            <p>Designed By <a href="http://www.webcloudkenya.com" rel="nofollow"target="_blank">Webcloud Kenya Ltd</a></p>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <!-- END FOOTER SECTION -->
</body>